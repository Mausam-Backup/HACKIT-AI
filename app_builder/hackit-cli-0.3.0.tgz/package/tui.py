import os
import sys
import asyncio
import subprocess
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.prompt import Prompt
from rich.spinner import Spinner

# Ensure package directory is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from structured_log import register_ws_callback
from orchestrator import run_pipeline
from config import Config

console = Console()

HACKIT_BANNER = """[bold cyan]
  ██╗  ██╗ █████╗  ██████╗██╗  ██╗██╗████████╗
  ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██║╚══██╔══╝
  ███████║███████║██║     █████╔╝ ██║   ██║   
  ██╔══██║██╔══██║██║     ██╔═██╗ ██║   ██║   
  ██║  ██║██║  ██║╚██████╗██║  ██╗██║   ██║   
  ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝   ╚═╝   
[/][bold gold1]   Autonomous AI Hackathon Coach & App Builder CLI[/]
"""

# TUI State Variables
current_stage = "initializing"
logs_buffer = []
stages_status = {
    "coach": "pending",      # pending, active, done, failed
    "builder": "pending",
    "validation": "pending",
    "pitch": "pending"
}


def tui_event_handler(event: str, **kwargs):
    global current_stage
    msg = kwargs.get("message", "")

    if event == "coach_start":
        stages_status["coach"] = "active"
        current_stage = "planning"
    elif event == "coach_complete":
        success = kwargs.get("success", True)
        stages_status["coach"] = "done" if success else "failed"
    elif event == "builder_start":
        stages_status["builder"] = "active"
        current_stage = "building"
    elif event == "builder_complete":
        success = kwargs.get("success", True)
        stages_status["builder"] = "done" if success else "failed"
    elif event == "validation_start":
        stages_status["validation"] = "active"
        current_stage = "validating"
    elif event == "validation_complete":
        passed = kwargs.get("passed", True)
        stages_status["validation"] = "done" if passed else "failed"
    elif event in ("pitch_update_start", "judge_start"):
        stages_status["pitch"] = "active"
        current_stage = "finalizing"
    elif event in ("pitch_update_complete", "judge_complete"):
        stages_status["pitch"] = "done"
    elif event == "pipeline_start":
        current_stage = "running"

    if msg:
        clean_msg = str(msg).strip()
        if clean_msg and (not logs_buffer or logs_buffer[-1] != clean_msg):
            logs_buffer.append(clean_msg)
            if len(logs_buffer) > 12:
                logs_buffer.pop(0)


def reset_stages():
    global logs_buffer, current_stage
    logs_buffer = []
    current_stage = "initializing"
    for key in stages_status:
        stages_status[key] = "pending"


def generate_layout():
    icons = {
        "pending": "[grey37]○ Pending[/]",
        "active": Spinner("dots", style="bold orange1"),
        "done": "[green]✓ Complete[/]",
        "failed": "[red]✗ Failed[/]"
    }

    table = Table.grid(padding=(0, 2))
    table.add_column("Status", width=14)
    table.add_column("Step")

    table.add_row(icons[stages_status["coach"]], "[bold]1. Coach Planning[/] (PLAN, ARCHITECTURE, TASKS, PROMPTS)")
    table.add_row(icons[stages_status["builder"]], "[bold]2. Code Generation[/] (Vite+React Frontend & Express Backend)")
    table.add_row(icons[stages_status["validation"]], "[bold]3. Validation & Repair[/] (Build, Lint, Tests & Auto-repair)")
    table.add_row(icons[stages_status["pitch"]], "[bold]4. Pitch & Evaluation[/] (HACKATHON update & JUDGE score)")

    log_text = Text()
    for log_line in logs_buffer:
        if "coach" in log_line.lower():
            log_text.append("  [HACKIT:Coach] ", style="bold cyan")
        elif "frontend" in log_line.lower() or "builder" in log_line.lower():
            log_text.append("  [HACKIT:Frontend] ", style="bold green")
        elif "backend" in log_line.lower():
            log_text.append("  [HACKIT:Backend] ", style="bold yellow")
        else:
            log_text.append("  ", style="grey62")
        log_text.append(f"{log_line}\n", style="grey78")

    progress_panel = Panel(
        table,
        title="[bold gold1]⚡ HACKIT Agent Pipeline Progress[/]",
        border_style="orange1",
        padding=(1, 2)
    )

    logs_panel = Panel(
        log_text,
        title="[bold cyan]💬 Live Agent Streaming Activity[/]",
        border_style="cyan",
        padding=(1, 2),
        height=14
    )

    header_text = Text(" HACKIT — Autonomous AI App Builder & Hackathon Coach", style="bold white on blue")

    return Group(
        header_text,
        Text("\n"),
        progress_panel,
        Text("\n"),
        logs_panel
    )


def show_help():
    table = Table(title="[bold gold1]HACKIT Chat Commands[/]", border_style="cyan")
    table.add_column("Command", style="bold cyan", width=20)
    table.add_column("Description")
    table.add_row("/help", "Show this help menu")
    table.add_row("/gui", "Launch Web GUI server & open browser")
    table.add_row("/plan <idea>", "Run Coach planning phase only (docs + architecture)")
    table.add_row("/build <idea>", "Run full pipeline (Coach -> Builder -> Validation)")
    table.add_row("/clear", "Clear terminal screen")
    table.add_row("/exit or /quit", "Exit HACKIT CLI")
    table.add_row("<project idea>", "Type any project idea to run full build")
    console.print(table)


async def execute_task(task_input: str, mode: str = "full", parent_dir: str = "."):
    reset_stages()
    parent_dir = os.path.abspath(parent_dir)
    config = Config.from_yaml()

    console.print(f"\n[bold green]🚀 [HACKIT] Initializing workspace for idea:[/] [cyan]{task_input}[/]\n")

    with Live(generate_layout(), console=console, refresh_per_second=4) as live:
        try:
            await run_pipeline(
                task=task_input,
                config=config,
                mode=mode,
                parent_dir=parent_dir
            )
        except Exception as e:
            logs_buffer.append(f"FATAL ERROR: {e}")

        live.update(generate_layout())

    from scaffold import slugify
    slug = slugify(task_input)
    project_path = os.path.join(parent_dir, slug)

    console.print("\n" + "=" * 64, style="bold green")
    console.print(f"🎉 SUCCESS: Project [bold cyan]{slug}[/] ready!", style="bold green")
    console.print("=" * 64 + "\n", style="bold green")

    console.print(f"📁 Project Path: [bold]{project_path}[/]")
    console.print(f"🚀 Quick Start: [bold yellow]cd \"{project_path}\" && npm run dev[/]\n")


async def main_async():
    os.environ["RUNNING_IN_TUI"] = "1"
    register_ws_callback(tui_event_handler)

    console.clear()
    console.print(HACKIT_BANNER)

    cli_args = process_cli_args()
    if cli_args:
        await execute_task(cli_args)
        return

    console.print("[dim]Type your project idea or type [bold cyan]/help[/] for commands.[/dim]\n")

    while True:
        try:
            user_input = Prompt.ask("[bold cyan]hackit >[/]").strip()
            if not user_input:
                continue

            cmd_lower = user_input.lower()

            if cmd_lower in ("/exit", "/quit", "exit", "quit"):
                console.print("\n[bold orange1]Goodbye from HACKIT! Happy hacking! 🏆[/]\n")
                break

            elif cmd_lower in ("/help", "help"):
                show_help()

            elif cmd_lower in ("/gui", "/dashboard", "gui", "dashboard"):
                console.print("\n[bold green]🚀 Launching HACKIT Web GUI Server...[/]")
                dash_path = os.path.join(os.path.dirname(__file__), "dashboard.py")
                subprocess.Popen([sys.executable, dash_path])
                console.print("🌐 Dashboard server running at [bold cyan]http://127.0.0.1:4097[/]\n")

            elif cmd_lower in ("/clear", "clear"):
                console.clear()
                console.print(HACKIT_BANNER)

            elif cmd_lower.startswith("/plan "):
                idea = user_input[6:].strip()
                if idea:
                    await execute_task(idea, mode="coach")
                else:
                    console.print("[red]Please specify an idea: /plan <your idea>[/]")

            elif cmd_lower.startswith("/build "):
                idea = user_input[7:].strip()
                if idea:
                    await execute_task(idea, mode="full")
                else:
                    console.print("[red]Please specify an idea: /build <your idea>[/]")

            else:
                await execute_task(user_input, mode="full")

        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold orange1]HACKIT session closed.[/]\n")
            break


def process_cli_args() -> str | None:
    args = process_raw_args()
    if args:
        first = args[0].lower()
        if first not in ("gui", "dashboard", "--gui"):
            return " ".join(args)
    return None


def process_raw_args():
    return [a for a in sys.argv[1:] if not a.endswith(".py")]


if __name__ == "__main__":
    try:
        asyncio.run(main_async())
    except KeyboardInterrupt:
        console.print("\n[red]Process aborted by user.[/]")

