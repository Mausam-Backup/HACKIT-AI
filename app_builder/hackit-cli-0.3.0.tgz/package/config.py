from pydantic import BaseModel
import yaml
import os


class Config(BaseModel):
    http_timeout: int = 3600
    server_port: int = 4190
    strict_models: bool = False
    max_repair_attempts: int = 2

    # Models for each agent
    coach_model: str = "default"
    builder_model: str = "default"

    # Builder timeout (per agent)
    builder_timeout: int = 1800

    # Coach timeout
    coach_timeout: int = 300

    @classmethod
    def from_yaml(cls, path: str = "config.yaml") -> "Config":
        if not os.path.exists(path):
            return cls()
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**(data or {}))
